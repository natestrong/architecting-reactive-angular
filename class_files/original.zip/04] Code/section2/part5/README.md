# Install

```
npm install http-server -g
```

# Run

```
http-server -p 5000

go to browser and http://localhost:5000
open developer tools, now in UI start typing and stop for 0.5 seconds and look at developer tools and the logs
```
