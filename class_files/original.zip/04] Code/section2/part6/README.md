# Install

```
npm install
```
This should install `rxjs`

# Run

```
npm start
```