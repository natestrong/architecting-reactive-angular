export interface AppState {
  counter: number;
  products: Array<any>;
}