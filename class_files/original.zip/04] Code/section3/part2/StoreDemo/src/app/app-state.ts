import { Product } from './product';

export interface AppState {
  products: Array<Product>;
}