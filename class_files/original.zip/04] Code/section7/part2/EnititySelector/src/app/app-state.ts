import { State as ProductsState } from './product.reducer';

export interface AppState {
  products: ProductsState
};