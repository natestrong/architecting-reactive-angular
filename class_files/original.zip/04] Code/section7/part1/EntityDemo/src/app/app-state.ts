import { Product } from "./product";

export interface AppState {
  counter;
  products;
  prods
}