export const products = [{
  id: 1,
  name: 'CD'
},
  {
    id: 2,
    name: 'DVD'
  }]