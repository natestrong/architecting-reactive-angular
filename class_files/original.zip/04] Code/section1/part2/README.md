# Run the demoes

## Run mutable demo

```
npm run start:mutable
```

## Run immutable demo

```
npm run start:immutable
```
