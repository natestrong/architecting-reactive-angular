const createView = require('./create-view');
const listView = require('./list-view');

createView.save();
createView.save();

listView.remove(1);